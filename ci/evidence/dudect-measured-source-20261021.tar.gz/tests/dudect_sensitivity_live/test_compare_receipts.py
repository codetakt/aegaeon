"""Malformed compare capture must fail before any qualification is granted."""
import json,os,struct,tempfile,unittest
from pathlib import Path
import analysis_contract  # installs the pinned original native-proof module path
import compare_receipts as r
class CompareReceiptsTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.root=Path(os.environ['COMPARE_RECEIPT_FIXTURE']);cls.inv=json.loads((cls.root/'invocation.json').read_bytes());cls.bindings=cls.inv['bindings']
  with (cls.root/'signal.inputs').open('rb') as f:cls.prefix=f.read(48+r.N*37+32+r.N*4)
 def damaged(self,offset,value):
  with tempfile.TemporaryDirectory() as name:
   d=Path(name);os.symlink(self.root/'native.timing',d/'native.timing');data=bytearray(self.prefix);data[offset:offset+len(value)]=value;(d/'signal.inputs').write_bytes(data)
   with self.assertRaises(ValueError):r.verify(d,self.bindings,'zero','injected_clock')
 def test_wrong_magic(self):self.damaged(0,b'AEGSEN04')
 def test_wrong_batch(self):self.damaged(16,struct.pack('<Q',1))
 def test_wrong_stride(self):self.damaged(32,struct.pack('<Q',64))
 def test_wrong_class(self):self.damaged(48,b'\x02')
 def test_wrong_operand(self):self.damaged(48+r.N+1,b'\xff')
 def test_wrong_secret(self):self.damaged(48+r.N*33,b'\x01')
 def test_wrong_index(self):self.damaged(48+r.N*33+32,struct.pack('<I',1))
 def test_wrong_iterations(self):self.damaged(48+r.N*37+32,struct.pack('<I',48))
 def test_truncated(self):
  with tempfile.TemporaryDirectory() as name:
   d=Path(name);os.symlink(self.root/'native.timing',d/'native.timing');(d/'signal.inputs').write_bytes(b'AEGCMP01')
   with self.assertRaises(ValueError):r.verify(d,self.bindings,'zero','injected_clock')
if __name__=='__main__':unittest.main()
