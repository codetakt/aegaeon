Private six-case successor to the original-positive-control role correction.
The PR calibration and sensitivity scopes include CT32/64/128, SHA256,
HMAC message and HMAC key for both compilers. The designated statistic sets,
floors, fixed signal strengths and positive-control roles are unchanged.

The frozen four-case implementation and C64-P1 result (98/100) remain original
evidence. Saved-data replay and injected-clock tests are separate results.
This candidate does not qualify the old physical run, authorize its successors,
or admit CI. A new artifact-bound physical plan must validate the added targets.
